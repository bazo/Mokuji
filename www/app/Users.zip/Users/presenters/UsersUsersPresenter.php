<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of AdminUsersPresenter
 *
 * @author Martin
 */
class Users_UsersPresenter extends BaseModulePresenter{

    public function createComponentPage($name)
    {
        $page = new Page($this,$name);

        $item = $page->addItem("Link");
        $item->contentFactory = array($this,'createAddNewLink');

        $item = $page->addItem("grid");
        $item->contentFactory = array($this,'createComponentUsersGrid');
        $item->hasSnippets = true;
    }

    public function createAddNewLink(Item $page,$name)
    {
        $link = Html::el('a')->href($this->link('newUser!'))->class('ajax')->add(Html::el('div')->id('create-new-link')->add(Html::el('div')->id('icon'))->add(Html::el('span')->add('Create new')));
        return $link;
    }

    public function createComponentUsersGrid(Item $item, $name)
    {
        $grid = new DataGrid($this, $name);
        $model = new Admin_UserModel();
        $ds = $model->getDs();
        $grid->bindDataTable($ds);
        return $grid;
    }

    public function createComponentCreateFormEditUser($name)
    {

    }

    public function handleNewUser()
    {
        fd('si macher bazo');
    }
}
?>
