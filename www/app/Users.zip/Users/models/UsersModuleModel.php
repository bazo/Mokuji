<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of UsersModule
 *
 * @author Martin
 */
class UsersModuleInstallModel {

    private $tables = array('admin_users');

    public function __create()
    {
        db::addSubst('modules', 'admin_modules');
        db::addSubst('table', 'admin_users');
    }

    public function checkInstall($module)
    {
    	
        db::addSubst('modules', 'admin_modules');
        return db::select('*')->from(':modules:')->where('module_name = %s', $module)->fetch();
    }

    public function getStatus()
    {
        db::addSubst('modules', 'admin_modules');
        return db::select('status')->from(':modules:')->where('module_name = %s', 'Users')->fetch();
    }

    public function install()
    {
        $values = array(
            'module_name' => 'Users',
            'namespace' => 'Users'
        );
        db::query('CREATE TABLE IF NOT EXISTS `admin_users` (
                  `id` int(11) NOT NULL AUTO_INCREMENT,
                  `login` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
                  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
                  `group` tinyint(4) NOT NULL,
                  PRIMARY KEY (`id`),
                  UNIQUE KEY `login` (`login`),
                  UNIQUE KEY `login_2` (`login`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;');
        return db::insert(':modules:', $values)->execute();
    }

    public function uninstall()
    {
        return db::query('drop table :table:')->execute();
    }
}
?>
