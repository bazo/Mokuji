<?php
/**
 * Description of Users
 *
 * @author Martin
 */
class UsersModule implements IMokujiModule {

    private $model;

    public function register()
    {
        $installed = $this->checkInstall();
        if($installed === false || $installed === null) $this->install();
    }

    public function checkInstall()
    {
         $cache = Environment::getCache('modules.UsersModule');
         if($cache->offsetGet('installed') == true) return true;
         else
         {
             $this->model = new UsersModuleInstallModel();
             $result = $this->model->checkInstall('Users');
             if($result != false)
             {
                $cache = Environment::getCache('modules.UsersModule');
                $cache->save('installed', true);
				return $cache->offsetGet('installed');
             }
         }
        
    }

    public function install()
    {
        $result = $this->model->install();
        if($result != false)
        {
            $cache = Environment::getCache('UsersModule');
            $cache->save('installed', true);
        }
        return true;
    }

    public function getRoutes()
    {
        $routes = array();
        $routes[] = new Route('admin/users/<action>', array(
                                'module' => 'Users',
                                'presenter' => 'Users',
                                'action' => 'default',
                        ));
        return $routes;
    }

    public function uninstall()
    {
        $model = new UsersModuleInstallModel();
        return $model->uninstall();
    }

    public function getMenuItems()
    {
        return array(
            'Users' => ':Users:Users:'
        );
    }

    public function getActions()
    {
        return array(
            'toggle',
            'uninstall'
        );
    }

    public function getStatus()
    {
        $cache = Environment::getCache('modules.UsersModule');
        if($cache->offsetGet('status') == 'enabled') return 'enabled';
        if($cache->offsetGet('status') == 'disabled') return 'disabled';
        else
        {
            $model = new UsersModuleInstallModel();
            $status = $model->getStatus();
			if($status == false){$status = new stdClass(); $status->status = 'disabled';}
            $cache->save('status', $status->status);
            return $cache->offsetGet('status');
        }
    }

    public function onStatusChange($new_status)
    {
        if($new_status == 'disabled')
        {
            $cache = Environment::getCache('modules.UsersModule');
            $cache->clean(array(Cache::ALL => TRUE));
        }
    }
}